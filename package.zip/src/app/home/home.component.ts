import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent   {

  imageObject: Array<object> = [{
    image: './assets/image1.png',
    thumbImage: './assets/image1.png',
    alt: 'alt of image',
    title: 'title of image',
}, {
    image: './assets/image2.png', // Support base64 image
    thumbImage: './assets/image2.png', // Support base64 image
    title: 'Image title', //Optional: You can use this key if want to show image with title
    alt: 'Image alt', //Optional: You can use this key if want to show image with alt
    order: 1 //Optional: if you pass this key then slider images will be arrange according @input: slideOrderType
},
{
  image: './assets/image3.png', // Support base64 image
  thumbImage: './assets/image3.png', //Optional: You can use this key if want to show image with title
  alt: 'Image alt', //Optional: You can use this key if want to show image with alt
  order: 1 //Optional: if you pass this key then slider images will be arrange according @input: slideOrderType
},
{
  image: './assets/image4.png', // Support base64 image
  thumbImage: './assets/image4.png', // Support base64 image
  title: 'Image title', //Optional: You can use this key if want to show image with title
  alt: 'Image alt', //Optional: You can use this key if want to show image with alt
  order: 1 //Optional: if you pass this key then slider images will be arrange according @input: slideOrderType
},
{
  image: './assets/image5.png', // Support base64 image
  thumbImage: './assets/image5.png', // Support base64 image
  title: 'Image title', //Optional: You can use this key if want to show image with title
  alt: 'Image alt', //Optional: You can use this key if want to show image with alt
  order: 1 //Optional: if you pass this key then slider images will be arrange according @input: slideOrderType
},
{
  video: 'https://www.youtube.com/embed/xRPjKQtRXR8?si=PZtl6tGj5e-bHoX5', // Youtube url
},
];
}